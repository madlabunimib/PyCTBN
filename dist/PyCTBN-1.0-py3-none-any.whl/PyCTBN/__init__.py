import PyCTBN.PyCTBN
from PyCTBN.PyCTBN import *
